package state;

public interface Activity {
    void makeOrder(Customer customer);
    void addProduct(Customer customer);
}
